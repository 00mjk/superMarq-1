API_URL = "https://flask-service.cgvd1267imk10.us-east-1.cs.amazonlightsail.com"
API_VERSION = "v0.1"
